package csc305.trial2;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.IOException;

public class DashboardController
{
    @javafx.fxml.FXML
    private BorderPane BorderPane;
    @javafx.fxml.FXML
    private Button SystemUpdatesBuuton;
    @javafx.fxml.FXML
    private Button ManageSubmarineEventButton;
    @javafx.fxml.FXML
    private Button SystemSecurityButton;
    @javafx.fxml.FXML
    private Button ExhibitMaintenanceButton;
    @javafx.fxml.FXML
    private Button LogOutButton;
    @javafx.fxml.FXML
    private Button BackUpButton;

    @javafx.fxml.FXML
    public void initialize() {
    }

    @javafx.fxml.FXML
    public void handleExhibitMaintenance(ActionEvent actionEvent) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("ExhibitMaintenance.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) BorderPane.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Exhibit Maintenance");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @javafx.fxml.FXML
    public void handleSystemSecurity(ActionEvent actionEvent) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("SystemSecurity.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) BorderPane.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("System Security");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @javafx.fxml.FXML
    public void handleManageSubmarineEvent(ActionEvent actionEvent) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("ManageSubmarineEvent.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) BorderPane.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Manage Submarine Event");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @javafx.fxml.FXML
    public void handleBackup(ActionEvent actionEvent) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("BackUp.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) BorderPane.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Back Up");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @javafx.fxml.FXML
    public void handleSystemUpdates(ActionEvent actionEvent) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("SystemUpdates.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) BorderPane.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("System Updates");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @javafx.fxml.FXML
    public void handleLogOut(ActionEvent actionEvent) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Login.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) BorderPane.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Login");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
