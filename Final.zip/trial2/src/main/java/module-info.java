module csc305.trial2 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;


    opens csc305.trial2 to javafx.fxml;
    exports csc305.trial2;
}