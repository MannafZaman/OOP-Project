package model;

public class CryptographicTask {
    private String taskDescription;
    private String status;

    public CryptographicTask(String taskDescription, String status) {
        this.taskDescription = taskDescription;
        this.status = status;
    }

    public String getTaskDescription() {
        return taskDescription;
    }

    public String getStatus() {
        return status;
    }
}
