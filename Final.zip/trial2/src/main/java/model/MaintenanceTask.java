package model;

public class MaintenanceTask {
    private String taskName;
    private boolean completed;

    public MaintenanceTask(String taskName, boolean completed) {
        this.taskName = taskName;
        this.completed = completed;
    }

    public String getTaskName() {
        return taskName;
    }

    public boolean isCompleted() {
        return completed;
    }
}
